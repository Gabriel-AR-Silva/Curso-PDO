<?php

function dd($dump)
{ 
    var_dump($dump);
    die();
}